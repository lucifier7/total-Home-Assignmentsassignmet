﻿using System;
namespace ArrayElements
{
    class MainClass
    {
        static void Main()
        {
            int[] arr = new int[] { 5, 7, 9, 6, 5, 4, 12, 21 };

            int sum = 0;
            int max = arr[0];
            int min = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                sum = sum + arr[i];



                if (arr[i] > max)
                {
                    max = arr[i];
                }
                if (arr[i] < min)
                {
                    min = arr[i];
                }
            }
            float average = sum / arr.Length;
            Console.WriteLine("Average Value Of Array Elements : {0}", average);
            Console.WriteLine("Maximum Value in Array : {0}", max);
            Console.WriteLine("Minimum Value in Array : {0}", min);
        }
    }
}
