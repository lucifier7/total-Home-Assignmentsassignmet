﻿using System;
namespace PalindromWord
{
    class MainClass
    {
        static void Main()
        {
            string rev;

            Console.WriteLine(" Enter the word: ");
            string v = Console.ReadLine();
            char[] ch = v.ToCharArray();
            Array.Reverse(ch);
            rev = new string(ch);
            bool b = v.Equals(rev, StringComparison.OrdinalIgnoreCase);
            if (b == true)
            {
                Console.WriteLine(" " + v + " is a Palindrome!");
            }
            else
            {
                Console.WriteLine(" " + v + " is not a Palindrome!");
            }



        }
    }
}



