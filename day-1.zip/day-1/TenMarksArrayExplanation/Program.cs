﻿using System;
namespace Marks
{
    class MainClass
    {
        static void Main()
        {
            int[] arr = new int[10];
            int sum = 0;
            double avg;
            int max = arr[0];
            int min = arr[0];



            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Enter Marks:");
                arr[i] = Convert.ToInt32(Console.ReadLine());
                sum = sum + arr[i];
                if (arr[i] > max)
                {
                    max = arr[i];
                }
                if (arr[i] < min)
                {
                    min = arr[i];
                }
            }
            avg = sum / arr.Length;
            Console.WriteLine("1.Total : {0}", sum);
            Console.WriteLine("2.Average of Marks : {0}", avg);
            Console.WriteLine("3.Maximum in Marks : {0}", max);
            Console.WriteLine("4.Minimum in Marks : {0}", min);



        }
    }
}
