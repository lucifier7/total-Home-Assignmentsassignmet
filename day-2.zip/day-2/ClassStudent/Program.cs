﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ClassStudent
{
    class student
    {
        public int rollNumber;
        public string name;
        public string classname;
        public int sem;
        public string branch;
        public float average;






        public void Display()
        {
            int marks1, marks2, marks3, marks4, marks5;
            
            float total;
            Console.WriteLine("Enter Maths Marks:");
            marks1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Science Marks:");
            marks2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Social Marks:");
            marks3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter English Marks:");
            marks4 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Sanskrit Marks:");
            marks5 = Convert.ToInt32(Console.ReadLine());
            total = marks1 + marks2 + marks3 + marks4 + marks5;

            Console.WriteLine("Total Marks:" + total);


            Console.WriteLine("Average:" +average);
            if (average > 35)
            {
                Console.WriteLine("Failed");
            }
            else if (average < 35 && average < 50)
            {
                Console.WriteLine("Failed");



            }
            else if (average > 50)
            {
                Console.WriteLine("Passed");
            }



        }
        public static void Main()
        {
            student s = new student();
            s.rollNumber = 101;
            s.name = "sravani";
            s.classname = "Asection";
            s.sem = 5;
            s.branch = "cse";
            Console.WriteLine(s.rollNumber);
            Console.WriteLine(s.name);
            Console.WriteLine(s.classname);
            Console.WriteLine(s.sem);
            Console.WriteLine(s.branch);
            marks m = new marks[10];
            m.rollNumber = 123;
            m.name = s.name;
            m.classname = s.classname;
            m.sem = s.sem;
            m.branch = s.branch;

            m.Display();
        }
    }
}


