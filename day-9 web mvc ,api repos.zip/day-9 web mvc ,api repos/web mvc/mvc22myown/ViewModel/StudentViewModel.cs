﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc22myown.ViewModel
{
    public class StudentViewModel
    {
        public int vmId { get; set; }
        public string vmName { get; set; }
        public string vmSubject { get; set; }
    }
}