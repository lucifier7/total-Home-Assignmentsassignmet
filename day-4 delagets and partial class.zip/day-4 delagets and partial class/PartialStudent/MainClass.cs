﻿
namespace PartialStudent
{
   public class MainClass
    {
        public static void Main()
        {
            Student s1 = new Student("sony", 12, 89);
            Console.WriteLine(s1.PrintMarkSheet());
        }

    }
}