﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public delegate void PrintDelegate();


namespace DelegateImplementationWithMultipleClasses
{
    class PrintingService
    {
        public static void Print(PrintDelegate d)
        {
            d();
        }

    }
}
