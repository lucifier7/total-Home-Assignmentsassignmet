﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateImplementationWithMultipleClasses
{
     class Customer
    {
        int custID;
        string custName;
        public Customer(int id,string name)
        {
            this.custID = id;
            this.custName = name;
        }

        private void Display()
        {
            Console.WriteLine("CustId : {0}",this.custID);
            Console.WriteLine("CustName : {0}",this.custName);
        }
        public void AvailService()
        {
            PrintDelegate d = new PrintDelegate(Display);
            PrintingService.Print(d);
        }


    }
}
