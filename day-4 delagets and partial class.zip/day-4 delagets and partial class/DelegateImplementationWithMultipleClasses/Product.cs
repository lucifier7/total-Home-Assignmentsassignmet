﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateImplementationWithMultipleClasses
{
     class Product
    {
        int ProdId;
        string ProdName;
        public Product(int id,string name)
        {
            this.ProdId = id;
            this.ProdName = name;
        }

        private void DisplayDetails()
        { 
            Console.WriteLine("Product ID is {0}",this.ProdId);
            Console.WriteLine("Product ID is {0}", this.ProdName);
        }
        public void UseService() 
        {
            PrintDelegate d = new PrintDelegate(DisplayDetails);
            PrintingService.Print(d);

        }

    }
}
