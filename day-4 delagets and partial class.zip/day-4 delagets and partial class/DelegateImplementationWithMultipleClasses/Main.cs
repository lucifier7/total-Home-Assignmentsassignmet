﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateImplementationWithMultipleClasses
{
  class MainClass
    {
        static void Main()
        {
            Customer cust = new Customer(101, "Sony");
            Product prod = new Product(111, "Bolt");
            Employee emp = new Employee(2051, "Sony", 12000, 10000, 8000);


            Console.WriteLine("------------------------------------------Customer AvailService----------");
            cust.AvailService();
            Console.WriteLine("------------------------------------------Product UserService----------");
            prod.UseService();
            Console.WriteLine("------------------------------------------Employee Generate Salary Slip Service----------");
            emp.GenerateSalarySlip();


        }
    }



}