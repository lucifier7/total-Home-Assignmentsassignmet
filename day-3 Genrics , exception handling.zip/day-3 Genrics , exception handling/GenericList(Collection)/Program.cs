﻿class MainClass
{
    public static void Main()
    {
        List<int> intlist = new List<int>(); // what if we dont mention datatype
        intlist.Add(10);
        intlist.Add(20);
        intlist.Add(6);
        intlist.Add(50);
        intlist.Add(50);
         


        foreach (int i in intlist)
        {
            Console.WriteLine(i);
        }
        Console.WriteLine("List Capacity is :"+ intlist.Capacity);
        Console.WriteLine("List Capacity is :" + intlist.Count);


    }
}
